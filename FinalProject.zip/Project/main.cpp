//Justin Yun

#include "mainwindow.h"
#include "player_stats.h"
#include "function.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    return a.exec();
}
